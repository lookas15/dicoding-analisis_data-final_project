# Bike-Sharing System Dashboard 🚲

## Setup Environment - Shell/Terminal

* mkdir proyek_akhir_analisis_data
* cd proyek_akhir_analisis_data
* pipenv install
* pipenv shell
* pip install -r requirements.txt

## Run Dashboard

streamlit run submission\dashboard\dashboard.py
